from django.apps import AppConfig


class StudentResultConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'student_result'
